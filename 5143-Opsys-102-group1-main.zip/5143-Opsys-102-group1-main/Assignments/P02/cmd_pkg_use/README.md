
### Instructions

* This directory contains files necessary for **creating the sqlite table** and **implementing the shell.**

* This directory further contains **another directory** [cmd_pkg](https://github.com/chill-chin/5143-Opsys-102-group1/tree/main/Assignments/P02/cmd_pkg_use/cmd_pkg) that contains all the shell commands that we implemented for this project.

* Refer to this [README](https://github.com/chill-chin/5143-Opsys-102-group1/blob/main/Assignments/P02/README.md) for further instructions and information about the shell command implementation.
