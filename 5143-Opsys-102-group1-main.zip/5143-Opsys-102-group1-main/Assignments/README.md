## Assignments

|   #   | Folder Link                            | Description                               |
| :---: | -------------------------------------- | ---------------------------------------------------- |
|   1   | [**P02**](https://github.com/chill-chin/5143-Opsys-102-group1/tree/main/Assignments/P02) | [Shell implementation using Virtual Filesystem](https://github.com/chill-chin/5143-Opsys-102-group1/tree/main/Assignments/P02) |
|   2   | [**P03**](https://github.com/chill-chin/5143-Opsys-102-group1/tree/main/Assignments/P03) | [CPU Scheduling](https://github.com/chill-chin/5143-Opsys-102-group1/tree/main/Assignments/P03) |
